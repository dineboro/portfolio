import  my_portrait from './my_portrait.PNG';


const My_portrait= ()=>{
    return(
        <img className='my__portrait' src={my_portrait} alt="about img" />
    )
}

export default My_portrait;