import React from "react";

function ViewButton(){
    return(
        <a href="#link">
            <button className="">View My Work</button>
        </a>
    )
}

export default ViewButton;